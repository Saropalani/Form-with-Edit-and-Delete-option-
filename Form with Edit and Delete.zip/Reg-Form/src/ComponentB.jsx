import React, {useState} from "react";
import { useTable, useSortBy } from 'react-table';
import { FaSort } from 'react-icons/fa';
import {FaTrash, FaEdit} from 'react-icons/fa';




function Table({data, setData, editRow}) { 
 
  if (!data || !Array.isArray(data)) {
    return null;
  }
 
  
  function deleteData (rowIndex) {
    console.log(rowIndex, "delete");
    let total=[...data]
    total.splice(rowIndex,1)
    setData(total);
  }

  


  const columns = React.useMemo(
    () => [
      { Header: 'Employee Name', accessor: 'Employee Name' },
      { Header: 'Gender', accessor: 'Gender' },
      { Header: 'Department', accessor: 'Department' },
      { Header: 'Date of Join', accessor: 'Date of Join' },
      { Header: 'Email', accessor: 'Email' },
      {
        Header: 'Action',
        accessor: 'Action',
        disableSortBy: true,
        Cell: ({ row }) => (
          <div className="action">
            <FaTrash onClick={() => deleteData(row.Index)} className="fa-trash" />
            <FaEdit onClick={() => editRow(row.original)} className="fa-edit"/>
          </div>
        )
      }
    ],
    [data, setData, editRow]
  ); 

 

  const {
    getTableProps,
    getTableBodyProps,
    headerGroups,
    rows,
    prepareRow,
  } = useTable(
    {
      columns,
      data,
    },
    useSortBy
  );

  return (
    <table
      id='table'
      className='table-container'
      style={{ display: data.length === 0 ? 'none' : 'table' }}
      {...getTableProps()}
    >
      <thead>
        {headerGroups.map((headerGroup) => (
          <tr {...headerGroup.getHeaderGroupProps()}>
            {headerGroup.headers.map((column) => (
              <th {...column.getHeaderProps(column.getSortByToggleProps())}>
                {column.render('Header')}
               {column.id !== 'Action' &&
                  (<span>
                    {column.isSorted ? (column.isSortedDesc ? '▼ ' : '▲') : <FaSort />}
                  </span>)}
              </th>
            ))}
          </tr>
        ))}
      </thead>
      <tbody {...getTableBodyProps()}>
        {rows.map((row, rowIndex) => {
          prepareRow(row);
        return (
            <tr key={rowIndex} {...row.getRowProps()}>
              {row.cells.map((cell, cellIndex) => (
                <td key={cellIndex} {...cell.getCellProps()}>
                  {cell.render('Cell')}
                </td>
              ))}
            </tr>
          );
        })}
      </tbody>
    </table>
  );
}

export default Table;
